//
//  twitterVII.h
//  loginSDK
//
//  Created by xy on 2023/6/7.
//  Copyright © 2023 gumo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TwitterSDK : NSObject
+(TwitterSDK*)getInstance;
@property (nonatomic,strong)NSString * ConsumerKey;
@property (nonatomic,strong)NSString* client_id;
-(void)loginSuccess:(void(^)(NSDictionary *))success failure:(void(^)(void))failure;
 
@end

NS_ASSUME_NONNULL_END
